Default Readme file from one of Azumatt's Templates. Replace this with actual content.
